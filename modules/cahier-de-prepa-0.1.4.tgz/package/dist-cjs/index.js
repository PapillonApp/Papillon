"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ParseError = exports.AuthenticationError = exports.HttpError = exports.CahierDePrepaError = exports.CookieJar = exports.FetchTransport = exports.Session = exports.Instance = exports.CahierDePrepa = void 0;
const Instance_1 = require("./structures/Instance");
const routes_1 = require("./routes");
class CahierDePrepa {
    session;
    home;
    recent;
    agenda;
    documents;
    constructor(url, transport) { this.session = new Instance_1.Instance(url).session(transport); this.home = new routes_1.HomeRoute(this.session); this.recent = new routes_1.RecentRoute(this.session); this.agenda = new routes_1.AgendaRoute(this.session); this.documents = new routes_1.DocumentsRoute(this.session); }
    login(username, password) { return this.session.login(username, password); }
}
exports.CahierDePrepa = CahierDePrepa;
var Instance_2 = require("./structures/Instance");
Object.defineProperty(exports, "Instance", { enumerable: true, get: function () { return Instance_2.Instance; } });
var Session_1 = require("./structures/Session");
Object.defineProperty(exports, "Session", { enumerable: true, get: function () { return Session_1.Session; } });
var network_1 = require("./structures/network");
Object.defineProperty(exports, "FetchTransport", { enumerable: true, get: function () { return network_1.FetchTransport; } });
Object.defineProperty(exports, "CookieJar", { enumerable: true, get: function () { return network_1.CookieJar; } });
var errors_1 = require("./structures/errors");
Object.defineProperty(exports, "CahierDePrepaError", { enumerable: true, get: function () { return errors_1.CahierDePrepaError; } });
Object.defineProperty(exports, "HttpError", { enumerable: true, get: function () { return errors_1.HttpError; } });
Object.defineProperty(exports, "AuthenticationError", { enumerable: true, get: function () { return errors_1.AuthenticationError; } });
Object.defineProperty(exports, "ParseError", { enumerable: true, get: function () { return errors_1.ParseError; } });
__exportStar(require("./types/domain"), exports);
__exportStar(require("./structures/parsing"), exports);
__exportStar(require("./routes"), exports);
