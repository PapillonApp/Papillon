"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DocumentsRoute = exports.AgendaRoute = exports.RecentRoute = exports.HomeRoute = void 0;
const parsing_1 = require("../structures/parsing");
class HomeRoute {
    session;
    constructor(session) {
        this.session = session;
    }
    async get() { const response = await this.session.request(''); return (0, parsing_1.parseHome)(await response.text(), this.session.instance.url); }
}
exports.HomeRoute = HomeRoute;
class RecentRoute {
    session;
    constructor(session) {
        this.session = session;
    }
    async get(filters = {}) {
        const response = await this.session.request('recent', {}, { type: filters.type, matiere: filters.matiere });
        return (0, parsing_1.parseRecent)(await response.text(), this.session.instance.url, filters);
    }
}
exports.RecentRoute = RecentRoute;
class AgendaRoute {
    session;
    constructor(session) {
        this.session = session;
    }
    async get() { const response = await this.session.request('agenda'); return (0, parsing_1.parseAgenda)(await response.text()); }
}
exports.AgendaRoute = AgendaRoute;
class DocumentsRoute {
    session;
    constructor(session) {
        this.session = session;
    }
    async list(folderId) { const response = await this.session.request('docs', {}, { rep: folderId }); return (0, parsing_1.parseDocuments)(await response.text(), this.session.instance.url, folderId); }
    async download(documentId, download = '') { const response = await this.session.request('download', {}, { id: documentId, dl: download }); return { response, contentType: response.headers.get('content-type'), filename: response.headers.get('content-disposition')?.match(/filename\*?=(?:UTF-8''|["']?)([^;"']+)/i)?.[1], arrayBuffer: () => response.arrayBuffer() }; }
}
exports.DocumentsRoute = DocumentsRoute;
