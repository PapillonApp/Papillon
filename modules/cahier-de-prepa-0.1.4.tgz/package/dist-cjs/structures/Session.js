"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Session = void 0;
const errors_1 = require("./errors");
class Session {
    instance;
    transport;
    authenticated = false;
    constructor(instance, transport) {
        this.instance = instance;
        this.transport = transport;
    }
    get isAuthenticated() { return this.authenticated; }
    async request(path, init = {}, params) {
        const url = this.instance.resolve(path, params);
        const response = await this.transport.request(url, init);
        if (!response.ok)
            throw new errors_1.HttpError(`Cahier de Prépa request failed (${response.status})`, response.status, url.toString());
        return response;
    }
    async login(username, password) {
        const homeResponse = await this.request('');
        const html = await homeResponse.text();
        const token = /<input[^>]+name=["']csrf-token["'][^>]+value=["']([^"']*)/i.exec(html)?.[1] ?? /<meta[^>]+name=["']csrf-token["'][^>]+content=["']([^"']*)/i.exec(html)?.[1];
        const form = new URLSearchParams({ 'csrf-token': token ?? '', login: username, motdepasse: password, connexion: '1' });
        const response = await this.request('ajax.php', { method: 'POST', headers: { Accept: 'application/json, text/plain, */*', 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest', Origin: this.instance.url.origin, Referer: this.instance.url.toString() }, body: form });
        const body = await response.clone().text();
        let rejected = false;
        try {
            const result = JSON.parse(body);
            rejected = typeof result === 'object' && result !== null && 'etat' in result && result.etat === 'nok';
        }
        catch { /* Some instances return plain text instead of JSON. */ }
        const failed = rejected || (/invalid|incorrect|erreur|échec|failed|mauvais couple/i.test(body) && !/success|connecté|authenticated/i.test(body));
        if (failed || (response.redirected && /login|connexion/i.test(response.url)))
            throw new errors_1.AuthenticationError('Cahier de Prépa rejected the login');
        this.authenticated = true;
    }
}
exports.Session = Session;
