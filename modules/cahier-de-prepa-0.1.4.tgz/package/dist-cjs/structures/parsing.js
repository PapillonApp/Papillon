"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseHome = parseHome;
exports.parseRecent = parseRecent;
exports.parseAgenda = parseAgenda;
exports.parseDocuments = parseDocuments;
const linkedom_1 = require("linkedom");
const errors_1 = require("./errors");
function parse(html) {
    const { document } = (0, linkedom_1.parseHTML)(html);
    if (!document)
        throw new errors_1.ParseError('Unable to parse HTML');
    return document;
}
function text(node) { return node?.textContent?.replace(/\s+/g, ' ').trim() ?? ''; }
function absoluteHref(href, base) {
    try {
        return new URL(href, base).toString();
    }
    catch {
        return href;
    }
}
function title(document) { return text(document.querySelector('title')) || text(document.querySelector('h1')) || ''; }
function links(document, base) { return Array.from(document.querySelectorAll('a[href]')).map((a) => ({ text: text(a), href: absoluteHref(a.getAttribute('href'), base) })); }
function parseHome(html, base) { const document = parse(html); const description = document.querySelector('meta[name="description"]')?.getAttribute('content') ?? undefined; return { title: title(document), heading: text(document.querySelector('h1')), description, links: links(document, base), html }; }
function recentSubject(node, updateTitle) {
    const taggedSubject = text(node.querySelector('[class*="matiere"], [class*="subject"], .discipline, .category'));
    if (taggedSubject)
        return taggedSubject;
    // Some Cahier de Prépa updates embed the subject in a bracketed suffix,
    // e.g. "Travail pour ... [Mathématiques/Informations] (mise à jour)".
    const bracket = /\[([^\]]+)\]/.exec(updateTitle)?.[1];
    if (!bracket)
        return undefined;
    const subjects = ['Mathématiques', 'Informatique', 'Physique', 'Sciences industrielles de l’ingénieur', 'Sciences industrielles de l\'ingénieur', 'ITC'];
    return subjects.find((subject) => bracket.toLocaleLowerCase().includes(subject.toLocaleLowerCase()));
}
function parseRecent(html, base, filters = {}) {
    const document = parse(html);
    const items = Array.from(document.querySelectorAll('article, .recent-item, .recent, li')).map((node) => {
        const anchor = node.querySelector('a[href]');
        const updateTitle = text(anchor) || text(node.querySelector('h2,h3,strong')) || text(node);
        const subject = recentSubject(node, updateTitle);
        const useSubjectAsTitle = filters.type === 'agenda' || filters.type === 'infos' || filters.type === 'information' || filters.type === 'colles';
        const normalizedTitle = useSubjectAsTitle ? subject || updateTitle : updateTitle;
        return { title: normalizedTitle, subject: normalizedTitle, href: anchor ? absoluteHref(anchor.getAttribute('href'), base) : undefined, date: text(node.querySelector('time')) || undefined, emptyState: /aucun résultat n['’]a été trouvé pour cette recherche/i.test(text(node)) };
    }).filter((item) => !item.emptyState).map(({ emptyState: _emptyState, ...item }) => item);
    return { title: title(document), items, html, filters };
}
function parseAgenda(html) { const document = parse(html); const events = Array.from(document.querySelectorAll('article, .event, tr, li')).map((node) => ({ title: text(node.querySelector('h2,h3,strong,td:first-child')) || text(node), date: text(node.querySelector('time,.date')) || undefined, time: text(node.querySelector('.time')) || undefined, location: text(node.querySelector('.location')) || undefined, text: text(node) })).filter((event) => event.text); return { title: title(document), events, html }; }
function parseDocuments(html, base, folderId) {
    const document = parse(html);
    const entries = Array.from(document.querySelectorAll('a[href]')).flatMap((anchor) => {
        const href = anchor.getAttribute('href');
        const url = new URL(href, base);
        const name = text(anchor);
        if (!name)
            return [];
        const id = url.searchParams.get('rep') ?? url.searchParams.get('id') ?? undefined;
        const type = url.searchParams.has('rep') || /rep|folder|dossier/i.test(anchor.className) ? 'folder' : 'document';
        return [{ id, name, href: url.toString(), type }];
    });
    return { title: title(document), folderId, entries, html };
}
