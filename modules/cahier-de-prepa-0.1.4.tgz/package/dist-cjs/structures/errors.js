"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ParseError = exports.AuthenticationError = exports.HttpError = exports.CahierDePrepaError = void 0;
class CahierDePrepaError extends Error {
    status;
    url;
    constructor(message, options = {}) {
        super(message, { cause: options.cause });
        this.name = 'CahierDePrepaError';
        this.status = options.status;
        this.url = options.url;
    }
}
exports.CahierDePrepaError = CahierDePrepaError;
class HttpError extends CahierDePrepaError {
    constructor(message, status, url) { super(message, { status, url }); this.name = 'HttpError'; }
}
exports.HttpError = HttpError;
class AuthenticationError extends CahierDePrepaError {
    constructor(message = 'Authentication failed') { super(message); this.name = 'AuthenticationError'; }
}
exports.AuthenticationError = AuthenticationError;
class ParseError extends CahierDePrepaError {
    constructor(message, cause) { super(message, { cause }); this.name = 'ParseError'; }
}
exports.ParseError = ParseError;
