"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Instance = void 0;
const Session_1 = require("./Session");
const network_1 = require("./network");
class Instance {
    url;
    constructor(url) { this.url = Instance.normalize(url); }
    static normalize(input) {
        const url = new URL(input.toString());
        if (!/^https?:$/.test(url.protocol))
            throw new TypeError('Instance URL must use http or https');
        url.search = '';
        url.hash = '';
        if (!url.pathname.endsWith('/'))
            url.pathname += '/';
        return url;
    }
    session(transport) { return new Session_1.Session(this, transport ?? new network_1.FetchTransport()); }
    resolve(path, params) {
        const url = new URL(path.replace(/^\//, ''), this.url);
        for (const [key, value] of Object.entries(params ?? {}))
            if (value !== undefined)
                url.searchParams.set(key, value);
        return url;
    }
}
exports.Instance = Instance;
