"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FetchTransport = exports.CookieJar = void 0;
class CookieJar {
    cookies = new Map();
    absorb(response) {
        const headers = response.headers;
        const values = headers.getSetCookie?.() ?? (headers.get('set-cookie') ? [headers.get('set-cookie')] : []);
        for (const value of values) {
            const first = value.split(';', 1)[0];
            const index = first.indexOf('=');
            if (index > 0)
                this.cookies.set(first.slice(0, index).trim(), first.slice(index + 1).trim());
        }
    }
    header() { return [...this.cookies].map(([key, value]) => `${key}=${value}`).join('; '); }
}
exports.CookieJar = CookieJar;
class FetchTransport {
    jar;
    fetcher;
    constructor(jar = new CookieJar(), fetcher = fetch) {
        this.jar = jar;
        this.fetcher = fetcher;
    }
    async request(input, init = {}) {
        const headers = new Headers(init.headers);
        const cookie = this.jar.header();
        if (cookie)
            headers.set('Cookie', cookie);
        const response = await this.fetcher(input, { ...init, headers, redirect: init.redirect ?? 'follow' });
        this.jar.absorb(response);
        return response;
    }
    get cookies() { return this.jar; }
}
exports.FetchTransport = FetchTransport;
