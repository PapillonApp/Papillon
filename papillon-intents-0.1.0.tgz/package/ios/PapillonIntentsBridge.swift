import Foundation

public final class PapillonIntentsBridge {
  public static let shared = PapillonIntentsBridge()
  private init() {}

  private let queue = DispatchQueue(label: "fr.strellastudio.papillon.intents.bridge")
  private var continuations: [String: CheckedContinuation<String, Error>] = [:]
  private var pending: [(id: String, action: String, params: [String: Any])] = []
  private var isReady = false

  /// Set by the Expo module (`OnCreate`); forwards a payload to JS as an event.
  public var sendEvent: (([String: Any]) -> Void)?
  public var defaultTimeoutMs: Int = 25000
  public var logLevel: String = "warn"

  public enum BridgeError: Error, LocalizedError {
    case timeout(String)
    case rejected(String)

    public var errorDescription: String? {
      switch self {
      case .timeout(let action): return "Papillon intent timed out (action: \(action))."
      case .rejected(let message): return message
      }
    }
  }

  public func fetch(
    action: String,
    params: [String: Any] = [:],
    timeoutMs: Int? = nil
  ) async throws -> String {
    let id = UUID().uuidString
    let timeout = timeoutMs ?? defaultTimeoutMs

    return try await withCheckedThrowingContinuation { (cont: CheckedContinuation<String, Error>) in
      queue.async {
        self.continuations[id] = cont

        self.queue.asyncAfter(deadline: .now() + .milliseconds(timeout)) { [weak self] in
          guard let self else { return }
          if let c = self.continuations.removeValue(forKey: id) {
            self.pending.removeAll { $0.id == id }
            c.resume(throwing: BridgeError.timeout(action))
          }
        }

        let payload: [String: Any] = ["requestId": id, "action": action, "params": params]
        if self.isReady, let send = self.sendEvent {
          DispatchQueue.main.async { send(payload) }
        } else {
          self.pending.append((id: id, action: action, params: params))
        }
      }
    }
  }

  public func resolve(id: String, json: String) {
    queue.async {
      if let cont = self.continuations.removeValue(forKey: id) {
        cont.resume(returning: json)
      }
    }
  }

  public func reject(id: String, message: String) {
    queue.async {
      if let cont = self.continuations.removeValue(forKey: id) {
        cont.resume(throwing: BridgeError.rejected(message))
      }
    }
  }

  public func setReady() {
    queue.async {
      self.isReady = true
      guard let send = self.sendEvent else { return }
      let toReplay = self.pending
      self.pending.removeAll()
      for item in toReplay {
        let payload: [String: Any] = [
          "requestId": item.id,
          "action": item.action,
          "params": item.params,
        ]
        DispatchQueue.main.async { send(payload) }
      }
    }
  }
}
