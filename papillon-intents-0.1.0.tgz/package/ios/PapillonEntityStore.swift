import Foundation

public final class PapillonEntityStore {
  public static let shared = PapillonEntityStore()
  private init() {}

  public var appGroup: String?

  private var defaults: UserDefaults {
    if let group = appGroup, let suite = UserDefaults(suiteName: group) {
      return suite
    }
    return .standard
  }

  private func key(_ type: String) -> String { "papillon.entities.\(type)" }

  public func save(type: String, json: String) {
    defaults.set(json, forKey: key(type))
    defaults.set(Date().timeIntervalSince1970, forKey: key(type) + ".ts")
  }

  public func loadJSON(type: String) -> String? {
    defaults.string(forKey: key(type))
  }

  public func loadArray(type: String) -> [[String: Any]] {
    guard
      let json = loadJSON(type: type),
      let data = json.data(using: .utf8),
      let array = (try? JSONSerialization.jsonObject(with: data)) as? [[String: Any]]
    else { return [] }
    return array
  }
}
