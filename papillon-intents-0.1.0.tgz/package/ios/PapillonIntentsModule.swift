import ExpoModulesCore

public class PapillonIntentsModule: Module {
  public func definition() -> ModuleDefinition {
    Name("PapillonIntents")

    Events("onIntentRequest")

    OnCreate {
      PapillonIntentsBridge.shared.sendEvent = { [weak self] payload in
        self?.sendEvent("onIntentRequest", payload)
      }
    }

    AsyncFunction("resolveRequest") { (requestId: String, payloadJson: String) in
      PapillonIntentsBridge.shared.resolve(id: requestId, json: payloadJson)
    }

    AsyncFunction("rejectRequest") { (requestId: String, message: String) in
      PapillonIntentsBridge.shared.reject(id: requestId, message: message)
    }

    Function("markReady") {
      PapillonIntentsBridge.shared.setReady()
    }

    Function("configure") { (settingsJson: String) in
      guard
        let data = settingsJson.data(using: .utf8),
        let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
      else { return }

      if let timeout = obj["defaultTimeoutMs"] as? Int {
        PapillonIntentsBridge.shared.defaultTimeoutMs = timeout
      }
      if let level = obj["logLevel"] as? String {
        PapillonIntentsBridge.shared.logLevel = level
      }
      if let group = obj["appGroup"] as? String, !group.isEmpty {
        PapillonEntityStore.shared.appGroup = group
      }
    }

    Function("setCache") { (entityType: String, payloadJson: String) in
      PapillonEntityStore.shared.save(type: entityType, json: payloadJson)
    }

    Function("getCache") { (entityType: String) -> String? in
      PapillonEntityStore.shared.loadJSON(type: entityType)
    }
  }
}
